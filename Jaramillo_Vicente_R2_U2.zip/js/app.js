
const formulario = document.getElementById("formulario");
const entradaTarea = document.getElementById("tarea");
const lista = document.getElementById("lista");
const contador = document.getElementById("contador");
const mensajeVacio = document.getElementById("vacio");
const botonLimpiar = document.getElementById("limpiar");

let tareas = [];

function actualizarContador() {
    const pendientes = tareas.filter(tarea => !tarea.completada).length;

    contador.textContent =
        `${pendientes} ${pendientes === 1 ? "tarea pendiente" : "tareas pendientes"}`;

    mensajeVacio.hidden = tareas.length > 0;
}

function renderizarTareas() {
    lista.replaceChildren();

    tareas.forEach(tarea => {
        const elemento = document.createElement("li");
        elemento.className = "tarea";

        if (tarea.completada) {
            elemento.classList.add("completada");
        }

        const casilla = document.createElement("input");
        casilla.type = "checkbox";
        casilla.checked = tarea.completada;
        casilla.setAttribute("aria-label", "Marcar tarea como completada");

        casilla.addEventListener("change", () => {
            tarea.completada = casilla.checked;
            renderizarTareas();
        });

        const texto = document.createElement("span");
        texto.textContent = tarea.texto;

        const eliminar = document.createElement("button");
        eliminar.type = "button";
        eliminar.className = "eliminar";
        eliminar.textContent = "Eliminar";
        eliminar.setAttribute("aria-label", `Eliminar ${tarea.texto}`);

        eliminar.addEventListener("click", () => {
            tareas = tareas.filter(item => item.id !== tarea.id);
            renderizarTareas();
        });

        elemento.append(casilla, texto, eliminar);
        lista.append(elemento);
    });

    actualizarContador();
}

formulario.addEventListener("submit", evento => {
    evento.preventDefault();

    const texto = entradaTarea.value.trim();

    if (!texto) {
        return;
    }

    tareas.push({
        id: Date.now() + Math.random(),
        texto: texto,
        completada: false
    });

    entradaTarea.value = "";
    entradaTarea.focus();

    renderizarTareas();
});

botonLimpiar.addEventListener("click", () => {
    tareas = tareas.filter(tarea => !tarea.completada);
    renderizarTareas();
});

renderizarTareas();
